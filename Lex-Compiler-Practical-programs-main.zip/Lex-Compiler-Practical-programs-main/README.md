# Lex-Compiler-Practical-programs
Lex programs compiler lab 
